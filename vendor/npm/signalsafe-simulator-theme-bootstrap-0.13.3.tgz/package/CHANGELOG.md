# Changelog

## 0.13.3 — prepared 2026-11-10

- Add repository, live example and related-package links; document the coordinated 100% coverage verification and synthetic editor example.

- Expose shared scrollbars and stable scrollbar space for bounded simulator panels.
- Preserve full-width SMS composers, shared call controls and responsive incoming-call layout.
- Retain the merged email normal-flow fix and its browser regression gate.

Prepared source version; npm publication and downstream registry-lock refresh are separate steps.

## 0.13.2 — release approved 2026-10-21

- Keep email fields and body in normal scroll flow so enlarged content cannot
  collapse the field group or pull the body over From/Subject.
- Add an actual public Device browser regression for narrow screens, enlarged
  text, long metadata and scroll reachability; retain all prior release gates.
- Preserve shared insets/navigation and all appearance JavaScript/declarations.

## [0.13.1] - Release approved 2026-10-21

Publication now waits for the existing hosted Sonar scan; the matching-tag-only publication condition is unchanged.

Includes the verified shared frame cascade and Step 6 email attachment layout/scroll ownership fixes. Pair with React `0.21.1`. The semantic `[hidden]` priority declaration remains intentional and its Sonar finding remains open.

## 0.13.3-local.20261109.2 — November 9, 2026

- Keep previous calls visible beneath the primary call buttons, without a collapse control. Increase caller number/status size and default contrast using shared theme tokens.

## 0.13.3-local.20261109.1 — November 9, 2026

- Present incoming caller history as a readable disclosure above call actions on every route. Remove route-dependent table styling while preserving the shared PhoneMe palette and phone layout.


## 0.13.0 — October 7, 2026

- Style the shared contact editor form, contact detail actions and editor screen, including the Back, Save and Delete controls.
- Style the shared phone-history layout, per-row Call button and summary title; keep the history search field consistent with the other search inputs (`.simulator-phone-history-screen`).
- Add `.prototype-page--plain` for app pages that render without the default content padding.
- Move `MIGRATION.md` and `RELEASING.md` into `docs/`.
- Own palette presets, the Night default, contrast selection and appearance token mapping in the explicit `appearance` runtime/type subpath.
- Add a single settings content inset and responsive card/form styles for shared Appearance, Screen password and Regional settings sections.
- Use the PhoneMe Night palette by default while retaining explicit appearance-token overrides.
- Consolidate Home clock and tile spacing in a shared Home stylesheet; let long localized dates and enlarged clock text wrap.
- Keep mint action and selected-state text legible with the shared contrast foreground.

## 0.12.1 — October 4, 2026

- Merge duplicate selectors and a repeated property declaration (SonarCloud); computed styles are unchanged.
- Remove repeated selectors inside selector lists in the phone contact detail and contacts styles.

## 0.12.0 — October 4, 2026

- Style the shared class names used by simulator-react and simulator-device 0.19.0.

Remove legacy conversion, wire and presentation aliases; migrate consumers to canonical contracts. See MIGRATION.md.

## Unreleased — shared PhoneMe UI

- Use one shared call view, avatar/navigation primitives, and full-width history-row presentation across scenario and provider hosts.
- Move the default PhoneMe palette and screen layout into the theme package; preserve host data, callbacks, and explicit appearance configuration.
- Verify narrow devices and enlarged text, and prevent duplicate message actions when shell navigation renders them.
- Local `ui` prereleases are packed integration artifacts, not registry releases.

## 0.10.0 — prepared September 29, 2026 (unpublished)

- Add scoped Vault, Photos, local Mail, settings and browser styles and plain error-list rows.
- Style call detail body media and number labels. Preserve existing semantic hooks and appearance tokens.
- Keep CSS imports consecutive and the final HTML `hidden` rule authoritative so overlays and scrolling retain their behavior.

- Require an exact version-tag match before CI publication; manual dispatch validates only.

## 0.9.2 — 2026-09-16

- Complete release documentation and include changelog/release instructions in the package.
- Document shared editor width, grouped cards and 44px photo actions introduced in 0.9.1.
- Clarify CSS-only ownership, supported source hooks and host customization boundaries.

## 0.9.1 — 2026-09-16

- Publish the shared contact editor/group/photo-action layout, appearance styles, dial/history refinements and wallpaper tokens.
- Release notes were completed in 0.9.2; the existing 0.9.1 tag remains immutable.


## 0.4.1 — 2026-09-11

- Make native heading text inside shared header rows inherit the row typography tokens and reset heading margins, avoiding competing browser defaults.

## 0.4.0 — 2026-09-11

- Add opt-in host bezel/scrolling and scoped controlled call, contact editor, history and Home tile styles.
- Include reviewed screen-header, compose, navigation and row token hooks used by PhoneMe local prereleases.
- Preserve default classes and host token overrides; include reduced-motion and focus treatments.
